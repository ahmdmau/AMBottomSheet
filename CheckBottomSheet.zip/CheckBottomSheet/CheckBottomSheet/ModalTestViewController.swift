//
//  ModalTestViewController.swift
//  CheckBottomSheet
//
//  Created by Ahmad Maulana on 31/12/19.
//  Copyright © 2019 Ahmad Maulana. All rights reserved.
//

import UIKit

class ModalTestViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//      if let controller = segue.destination as? ModalTestViewController {
//        controller.modalPresentationStyle = .fullScreen
//      }
//    }
    
    @IBAction func presentTestVC(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)

        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "TestVCViewController") as! TestVCViewController
//        nextViewController.modalPresentationStyle = .fullScreen
        let nav = UINavigationController(rootViewController: nextViewController)
        nav.modalPresentationStyle = .fullScreen
        self.present(nav, animated:true, completion:nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
