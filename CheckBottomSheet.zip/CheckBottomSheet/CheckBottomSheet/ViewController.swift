//
//  ViewController.swift
//  CheckBottomSheet
//
//  Created by Ahmad Maulana on 31/12/19.
//  Copyright © 2019 Ahmad Maulana. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    lazy var slideInTransitionDelegate = SlideInPresentationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      if let controller = segue.destination as? ModalTestViewController {
        slideInTransitionDelegate.direction = .bottom
        controller.transitioningDelegate = slideInTransitionDelegate
        controller.modalPresentationStyle = .custom
      }
    }

}

